﻿namespace quanlykhachsan
{
    partial class frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Tabphong = new System.Windows.Forms.TabControl();
            this.tpDanhSanh = new System.Windows.Forms.TabPage();
            this.dtgvDanhSachphong = new System.Windows.Forms.DataGridView();
            this.maPhong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.loaiPhong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tinhTrang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.donGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btndangxuat = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tpThuePhong = new System.Windows.Forms.TabPage();
            this.bHuyBo = new System.Windows.Forms.Button();
            this.btThuePhongOK = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dgkhachhang = new System.Windows.Forms.DataGridView();
            this.maKhachHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenKhachHang = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ngaySinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gioiTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chungMinhNhanDan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.soDienThoai = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.diaChi = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quocTich = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtmakhtp = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBDatPhong = new System.Windows.Forms.GroupBox();
            this.dtngaydattruoc = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.txtphongdt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBDatPhongTruoc = new System.Windows.Forms.CheckBox();
            this.txtPhongtp = new System.Windows.Forms.TextBox();
            this.dtTuNgaytp = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tpTimKiem = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dgTimKiem = new System.Windows.Forms.DataGridView();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.TKTheoDiaChi = new System.Windows.Forms.TextBox();
            this.cbTheoDiaChi = new System.Windows.Forms.CheckBox();
            this.TKTheoSoDT = new System.Windows.Forms.TextBox();
            this.cbTheoDT = new System.Windows.Forms.CheckBox();
            this.btTimKiem = new System.Windows.Forms.Button();
            this.TKTheoCMND = new System.Windows.Forms.TextBox();
            this.cbTheoCMND = new System.Windows.Forms.CheckBox();
            this.TKTheoMa = new System.Windows.Forms.TextBox();
            this.cbTheoMaKH = new System.Windows.Forms.CheckBox();
            this.TKDenNgay = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.TKTuNgay = new System.Windows.Forms.DateTimePicker();
            this.TKTheoTen = new System.Windows.Forms.TextBox();
            this.TKTheoPhong = new System.Windows.Forms.ComboBox();
            this.cbThoiGian = new System.Windows.Forms.CheckBox();
            this.cbTheoTen = new System.Windows.Forms.CheckBox();
            this.cbTheoPhong = new System.Windows.Forms.CheckBox();
            this.tpTraPhong = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.dgtraphong = new System.Windows.Forms.DataGridView();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtmathuephong = new System.Windows.Forms.TextBox();
            this.dtngaysinh = new System.Windows.Forms.DateTimePicker();
            this.txttongtien = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtdongiatp = new System.Windows.Forms.TextBox();
            this.dttpngaybatdauthue = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.dttpngayketthucthue = new System.Windows.Forms.DateTimePicker();
            this.label24 = new System.Windows.Forms.Label();
            this.txtTPPhong = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtTPTenKH = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtTPSoCMND = new System.Windows.Forms.TextBox();
            this.txtTPSoDT = new System.Windows.Forms.TextBox();
            this.txtTPDiaChi = new System.Windows.Forms.TextBox();
            this.TPTinhTien = new System.Windows.Forms.Button();
            this.Tabphong.SuspendLayout();
            this.tpDanhSanh.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDanhSachphong)).BeginInit();
            this.tpThuePhong.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgkhachhang)).BeginInit();
            this.groupBDatPhong.SuspendLayout();
            this.tpTimKiem.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTimKiem)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.tpTraPhong.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgtraphong)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // Tabphong
            // 
            this.Tabphong.Controls.Add(this.tpDanhSanh);
            this.Tabphong.Controls.Add(this.tpThuePhong);
            this.Tabphong.Controls.Add(this.tpTimKiem);
            this.Tabphong.Controls.Add(this.tpTraPhong);
            this.Tabphong.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.Tabphong.Location = new System.Drawing.Point(16, 15);
            this.Tabphong.Margin = new System.Windows.Forms.Padding(4);
            this.Tabphong.Name = "Tabphong";
            this.Tabphong.SelectedIndex = 0;
            this.Tabphong.Size = new System.Drawing.Size(1347, 735);
            this.Tabphong.TabIndex = 0;
            this.Tabphong.Click += new System.EventHandler(this.Tabphong_Click);
            // 
            // tpDanhSanh
            // 
            this.tpDanhSanh.AccessibleName = "";
            this.tpDanhSanh.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.tpDanhSanh.Controls.Add(this.dtgvDanhSachphong);
            this.tpDanhSanh.Controls.Add(this.btndangxuat);
            this.tpDanhSanh.Controls.Add(this.label2);
            this.tpDanhSanh.Location = new System.Drawing.Point(4, 29);
            this.tpDanhSanh.Margin = new System.Windows.Forms.Padding(4);
            this.tpDanhSanh.Name = "tpDanhSanh";
            this.tpDanhSanh.Padding = new System.Windows.Forms.Padding(4);
            this.tpDanhSanh.Size = new System.Drawing.Size(1339, 702);
            this.tpDanhSanh.TabIndex = 0;
            this.tpDanhSanh.Text = "Danh Sách";
            this.tpDanhSanh.UseVisualStyleBackColor = true;
            this.tpDanhSanh.Click += new System.EventHandler(this.tpDanhSanh_Click);
            // 
            // dtgvDanhSachphong
            // 
            this.dtgvDanhSachphong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvDanhSachphong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvDanhSachphong.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.maPhong,
            this.loaiPhong,
            this.tinhTrang,
            this.donGia});
            this.dtgvDanhSachphong.Location = new System.Drawing.Point(4, 64);
            this.dtgvDanhSachphong.Margin = new System.Windows.Forms.Padding(4);
            this.dtgvDanhSachphong.MultiSelect = false;
            this.dtgvDanhSachphong.Name = "dtgvDanhSachphong";
            this.dtgvDanhSachphong.ReadOnly = true;
            this.dtgvDanhSachphong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvDanhSachphong.Size = new System.Drawing.Size(1299, 407);
            this.dtgvDanhSachphong.TabIndex = 1;
            // 
            // maPhong
            // 
            this.maPhong.DataPropertyName = "maPhong";
            this.maPhong.HeaderText = "Phòng";
            this.maPhong.Name = "maPhong";
            this.maPhong.ReadOnly = true;
            // 
            // loaiPhong
            // 
            this.loaiPhong.DataPropertyName = "loaiPhong";
            this.loaiPhong.HeaderText = "Loại Phòng";
            this.loaiPhong.Name = "loaiPhong";
            this.loaiPhong.ReadOnly = true;
            // 
            // tinhTrang
            // 
            this.tinhTrang.DataPropertyName = "tinhTrang";
            this.tinhTrang.HeaderText = "Tình trạng";
            this.tinhTrang.Name = "tinhTrang";
            this.tinhTrang.ReadOnly = true;
            // 
            // donGia
            // 
            this.donGia.DataPropertyName = "donGia";
            this.donGia.HeaderText = "Đơn Giá";
            this.donGia.Name = "donGia";
            this.donGia.ReadOnly = true;
            // 
            // btndangxuat
            // 
            this.btndangxuat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btndangxuat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btndangxuat.Location = new System.Drawing.Point(1137, 25);
            this.btndangxuat.Margin = new System.Windows.Forms.Padding(4);
            this.btndangxuat.Name = "btndangxuat";
            this.btndangxuat.Size = new System.Drawing.Size(145, 32);
            this.btndangxuat.TabIndex = 2;
            this.btndangxuat.Text = "Đăng xuất";
            this.btndangxuat.UseVisualStyleBackColor = false;
            this.btndangxuat.Click += new System.EventHandler(this.btndangxuat_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label2.ForeColor = System.Drawing.Color.Fuchsia;
            this.label2.Location = new System.Drawing.Point(356, 25);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(554, 31);
            this.label2.TabIndex = 0;
            this.label2.Text = "DANH SÁCH PHÒNG TRONG KHÁCH SẠN";
            // 
            // tpThuePhong
            // 
            this.tpThuePhong.Controls.Add(this.bHuyBo);
            this.tpThuePhong.Controls.Add(this.btThuePhongOK);
            this.tpThuePhong.Controls.Add(this.groupBox5);
            this.tpThuePhong.Location = new System.Drawing.Point(4, 29);
            this.tpThuePhong.Margin = new System.Windows.Forms.Padding(4);
            this.tpThuePhong.Name = "tpThuePhong";
            this.tpThuePhong.Padding = new System.Windows.Forms.Padding(4);
            this.tpThuePhong.Size = new System.Drawing.Size(1339, 702);
            this.tpThuePhong.TabIndex = 1;
            this.tpThuePhong.Text = "Thuê Phòng";
            this.tpThuePhong.UseVisualStyleBackColor = true;
            // 
            // bHuyBo
            // 
            this.bHuyBo.Location = new System.Drawing.Point(672, 569);
            this.bHuyBo.Margin = new System.Windows.Forms.Padding(4);
            this.bHuyBo.Name = "bHuyBo";
            this.bHuyBo.Size = new System.Drawing.Size(153, 47);
            this.bHuyBo.TabIndex = 24;
            this.bHuyBo.Text = "Hủy bỏ";
            this.bHuyBo.UseVisualStyleBackColor = true;
            this.bHuyBo.Click += new System.EventHandler(this.bHuyBo_Click);
            // 
            // btThuePhongOK
            // 
            this.btThuePhongOK.Location = new System.Drawing.Point(369, 569);
            this.btThuePhongOK.Margin = new System.Windows.Forms.Padding(4);
            this.btThuePhongOK.Name = "btThuePhongOK";
            this.btThuePhongOK.Size = new System.Drawing.Size(153, 47);
            this.btThuePhongOK.TabIndex = 23;
            this.btThuePhongOK.Text = "OK";
            this.btThuePhongOK.UseVisualStyleBackColor = true;
            this.btThuePhongOK.Click += new System.EventHandler(this.btThuePhongOK_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.dgkhachhang);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.txtmakhtp);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.groupBDatPhong);
            this.groupBox5.Controls.Add(this.txtPhongtp);
            this.groupBox5.Controls.Add(this.dtTuNgaytp);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Location = new System.Drawing.Point(25, 6);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox5.Size = new System.Drawing.Size(1252, 537);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            // 
            // dgkhachhang
            // 
            this.dgkhachhang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgkhachhang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgkhachhang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.maKhachHang,
            this.tenKhachHang,
            this.ngaySinh,
            this.gioiTinh,
            this.chungMinhNhanDan,
            this.soDienThoai,
            this.diaChi,
            this.quocTich});
            this.dgkhachhang.Location = new System.Drawing.Point(8, 60);
            this.dgkhachhang.Margin = new System.Windows.Forms.Padding(4);
            this.dgkhachhang.Name = "dgkhachhang";
            this.dgkhachhang.ReadOnly = true;
            this.dgkhachhang.Size = new System.Drawing.Size(1220, 210);
            this.dgkhachhang.TabIndex = 31;
            this.dgkhachhang.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgkhachhang_CellClick);
            this.dgkhachhang.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgkhachhang_CellContentClick);
            // 
            // maKhachHang
            // 
            this.maKhachHang.DataPropertyName = "maKhachHang";
            this.maKhachHang.HeaderText = "Mã khách hàng";
            this.maKhachHang.Name = "maKhachHang";
            this.maKhachHang.ReadOnly = true;
            // 
            // tenKhachHang
            // 
            this.tenKhachHang.DataPropertyName = "tenKhachHang";
            this.tenKhachHang.HeaderText = "Tên khách hàng";
            this.tenKhachHang.Name = "tenKhachHang";
            this.tenKhachHang.ReadOnly = true;
            // 
            // ngaySinh
            // 
            this.ngaySinh.DataPropertyName = "ngaySinh";
            this.ngaySinh.HeaderText = "Ngày sinh";
            this.ngaySinh.Name = "ngaySinh";
            this.ngaySinh.ReadOnly = true;
            // 
            // gioiTinh
            // 
            this.gioiTinh.DataPropertyName = "gioiTinh";
            this.gioiTinh.HeaderText = "Giới tính";
            this.gioiTinh.Name = "gioiTinh";
            this.gioiTinh.ReadOnly = true;
            // 
            // chungMinhNhanDan
            // 
            this.chungMinhNhanDan.DataPropertyName = "chungMinhNhanDan";
            this.chungMinhNhanDan.HeaderText = "Chứng minh thư";
            this.chungMinhNhanDan.Name = "chungMinhNhanDan";
            this.chungMinhNhanDan.ReadOnly = true;
            // 
            // soDienThoai
            // 
            this.soDienThoai.DataPropertyName = "soDienThoai";
            this.soDienThoai.HeaderText = "Số điện thoại";
            this.soDienThoai.Name = "soDienThoai";
            this.soDienThoai.ReadOnly = true;
            // 
            // diaChi
            // 
            this.diaChi.DataPropertyName = "diaChi";
            this.diaChi.HeaderText = "Địa chỉ";
            this.diaChi.Name = "diaChi";
            this.diaChi.ReadOnly = true;
            // 
            // quocTich
            // 
            this.quocTich.DataPropertyName = "quocTich";
            this.quocTich.HeaderText = "Quốc tịch";
            this.quocTich.Name = "quocTich";
            this.quocTich.ReadOnly = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(395, 27);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(383, 31);
            this.label6.TabIndex = 30;
            this.label6.Text = "THÔNG TIN KHÁCH HÀNG :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(176, 300);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 20);
            this.label5.TabIndex = 29;
            this.label5.Text = "Mã KH :";
            // 
            // txtmakhtp
            // 
            this.txtmakhtp.Enabled = false;
            this.txtmakhtp.Location = new System.Drawing.Point(296, 293);
            this.txtmakhtp.Margin = new System.Windows.Forms.Padding(4);
            this.txtmakhtp.Name = "txtmakhtp";
            this.txtmakhtp.Size = new System.Drawing.Size(251, 26);
            this.txtmakhtp.TabIndex = 29;
            this.txtmakhtp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(171, 251);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 20);
            this.label4.TabIndex = 28;
            // 
            // groupBDatPhong
            // 
            this.groupBDatPhong.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBDatPhong.Controls.Add(this.dtngaydattruoc);
            this.groupBDatPhong.Controls.Add(this.label3);
            this.groupBDatPhong.Controls.Add(this.txtphongdt);
            this.groupBDatPhong.Controls.Add(this.label1);
            this.groupBDatPhong.Controls.Add(this.checkBDatPhongTruoc);
            this.groupBDatPhong.Location = new System.Drawing.Point(152, 393);
            this.groupBDatPhong.Margin = new System.Windows.Forms.Padding(4);
            this.groupBDatPhong.Name = "groupBDatPhong";
            this.groupBDatPhong.Padding = new System.Windows.Forms.Padding(4);
            this.groupBDatPhong.Size = new System.Drawing.Size(917, 118);
            this.groupBDatPhong.TabIndex = 26;
            this.groupBDatPhong.TabStop = false;
            // 
            // dtngaydattruoc
            // 
            this.dtngaydattruoc.CustomFormat = "dd/MM/yyyy";
            this.dtngaydattruoc.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtngaydattruoc.Location = new System.Drawing.Point(136, 66);
            this.dtngaydattruoc.Margin = new System.Windows.Forms.Padding(4);
            this.dtngaydattruoc.Name = "dtngaydattruoc";
            this.dtngaydattruoc.Size = new System.Drawing.Size(251, 26);
            this.dtngaydattruoc.TabIndex = 28;
            this.dtngaydattruoc.Value = new System.DateTime(2008, 12, 13, 0, 53, 0, 0);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 66);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 20);
            this.label3.TabIndex = 27;
            this.label3.Text = "Từ Ngày :";
            // 
            // txtphongdt
            // 
            this.txtphongdt.Location = new System.Drawing.Point(613, 64);
            this.txtphongdt.Margin = new System.Windows.Forms.Padding(4);
            this.txtphongdt.Name = "txtphongdt";
            this.txtphongdt.Size = new System.Drawing.Size(251, 26);
            this.txtphongdt.TabIndex = 28;
            this.txtphongdt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(511, 66);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 20);
            this.label1.TabIndex = 27;
            this.label1.Text = "Phòng :";
            // 
            // checkBDatPhongTruoc
            // 
            this.checkBDatPhongTruoc.AutoSize = true;
            this.checkBDatPhongTruoc.Location = new System.Drawing.Point(21, 26);
            this.checkBDatPhongTruoc.Margin = new System.Windows.Forms.Padding(4);
            this.checkBDatPhongTruoc.Name = "checkBDatPhongTruoc";
            this.checkBDatPhongTruoc.Size = new System.Drawing.Size(160, 24);
            this.checkBDatPhongTruoc.TabIndex = 27;
            this.checkBDatPhongTruoc.Text = "Đặt phòng trước :";
            this.checkBDatPhongTruoc.UseVisualStyleBackColor = true;
            this.checkBDatPhongTruoc.CheckedChanged += new System.EventHandler(this.checkBDatPhongTruoc_CheckedChanged);
            // 
            // txtPhongtp
            // 
            this.txtPhongtp.Location = new System.Drawing.Point(787, 345);
            this.txtPhongtp.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhongtp.Name = "txtPhongtp";
            this.txtPhongtp.Size = new System.Drawing.Size(251, 26);
            this.txtPhongtp.TabIndex = 22;
            this.txtPhongtp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dtTuNgaytp
            // 
            this.dtTuNgaytp.CustomFormat = "dd/MM/yyyy";
            this.dtTuNgaytp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtTuNgaytp.Location = new System.Drawing.Point(295, 347);
            this.dtTuNgaytp.Margin = new System.Windows.Forms.Padding(4);
            this.dtTuNgaytp.Name = "dtTuNgaytp";
            this.dtTuNgaytp.Size = new System.Drawing.Size(251, 26);
            this.dtTuNgaytp.TabIndex = 18;
            this.dtTuNgaytp.Value = new System.DateTime(2008, 12, 13, 0, 53, 0, 0);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(684, 347);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(66, 20);
            this.label12.TabIndex = 9;
            this.label12.Text = "Phòng :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(175, 347);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 20);
            this.label9.TabIndex = 6;
            this.label9.Text = "Từ Ngày :";
            // 
            // tpTimKiem
            // 
            this.tpTimKiem.Controls.Add(this.groupBox7);
            this.tpTimKiem.Controls.Add(this.groupBox6);
            this.tpTimKiem.Location = new System.Drawing.Point(4, 29);
            this.tpTimKiem.Margin = new System.Windows.Forms.Padding(4);
            this.tpTimKiem.Name = "tpTimKiem";
            this.tpTimKiem.Padding = new System.Windows.Forms.Padding(4);
            this.tpTimKiem.Size = new System.Drawing.Size(1339, 702);
            this.tpTimKiem.TabIndex = 2;
            this.tpTimKiem.Text = "Tìm Kiếm";
            this.tpTimKiem.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.dgTimKiem);
            this.groupBox7.Location = new System.Drawing.Point(20, 206);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox7.Size = new System.Drawing.Size(1235, 265);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Kết quả tìm kiếm :";
            // 
            // dgTimKiem
            // 
            this.dgTimKiem.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgTimKiem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTimKiem.Location = new System.Drawing.Point(20, 22);
            this.dgTimKiem.Margin = new System.Windows.Forms.Padding(4);
            this.dgTimKiem.Name = "dgTimKiem";
            this.dgTimKiem.ReadOnly = true;
            this.dgTimKiem.Size = new System.Drawing.Size(1203, 238);
            this.dgTimKiem.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.TKTheoDiaChi);
            this.groupBox6.Controls.Add(this.cbTheoDiaChi);
            this.groupBox6.Controls.Add(this.TKTheoSoDT);
            this.groupBox6.Controls.Add(this.cbTheoDT);
            this.groupBox6.Controls.Add(this.btTimKiem);
            this.groupBox6.Controls.Add(this.TKTheoCMND);
            this.groupBox6.Controls.Add(this.cbTheoCMND);
            this.groupBox6.Controls.Add(this.TKTheoMa);
            this.groupBox6.Controls.Add(this.cbTheoMaKH);
            this.groupBox6.Controls.Add(this.TKDenNgay);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.TKTuNgay);
            this.groupBox6.Controls.Add(this.TKTheoTen);
            this.groupBox6.Controls.Add(this.TKTheoPhong);
            this.groupBox6.Controls.Add(this.cbThoiGian);
            this.groupBox6.Controls.Add(this.cbTheoTen);
            this.groupBox6.Controls.Add(this.cbTheoPhong);
            this.groupBox6.Location = new System.Drawing.Point(20, 7);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox6.Size = new System.Drawing.Size(1223, 193);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Chọn thông tin tìm kiếm : ";
            // 
            // TKTheoDiaChi
            // 
            this.TKTheoDiaChi.Enabled = false;
            this.TKTheoDiaChi.Location = new System.Drawing.Point(771, 140);
            this.TKTheoDiaChi.Margin = new System.Windows.Forms.Padding(4);
            this.TKTheoDiaChi.Name = "TKTheoDiaChi";
            this.TKTheoDiaChi.Size = new System.Drawing.Size(181, 26);
            this.TKTheoDiaChi.TabIndex = 16;
            // 
            // cbTheoDiaChi
            // 
            this.cbTheoDiaChi.AutoSize = true;
            this.cbTheoDiaChi.Location = new System.Drawing.Point(616, 142);
            this.cbTheoDiaChi.Margin = new System.Windows.Forms.Padding(4);
            this.cbTheoDiaChi.Name = "cbTheoDiaChi";
            this.cbTheoDiaChi.Size = new System.Drawing.Size(138, 24);
            this.cbTheoDiaChi.TabIndex = 15;
            this.cbTheoDiaChi.Text = "Theo Địa Chị :";
            this.cbTheoDiaChi.UseVisualStyleBackColor = true;
            // 
            // TKTheoSoDT
            // 
            this.TKTheoSoDT.Location = new System.Drawing.Point(272, 138);
            this.TKTheoSoDT.Margin = new System.Windows.Forms.Padding(4);
            this.TKTheoSoDT.Name = "TKTheoSoDT";
            this.TKTheoSoDT.Size = new System.Drawing.Size(243, 26);
            this.TKTheoSoDT.TabIndex = 14;
            // 
            // cbTheoDT
            // 
            this.cbTheoDT.AutoSize = true;
            this.cbTheoDT.Location = new System.Drawing.Point(111, 139);
            this.cbTheoDT.Margin = new System.Windows.Forms.Padding(4);
            this.cbTheoDT.Name = "cbTheoDT";
            this.cbTheoDT.Size = new System.Drawing.Size(128, 24);
            this.cbTheoDT.TabIndex = 13;
            this.cbTheoDT.Text = "Theo số ĐT :";
            this.cbTheoDT.UseVisualStyleBackColor = true;
            // 
            // btTimKiem
            // 
            this.btTimKiem.Location = new System.Drawing.Point(985, 64);
            this.btTimKiem.Margin = new System.Windows.Forms.Padding(4);
            this.btTimKiem.Name = "btTimKiem";
            this.btTimKiem.Size = new System.Drawing.Size(108, 70);
            this.btTimKiem.TabIndex = 12;
            this.btTimKiem.Text = "Tìm Kiếm";
            this.btTimKiem.UseVisualStyleBackColor = true;
            this.btTimKiem.Click += new System.EventHandler(this.btTimKiem_Click);
            // 
            // TKTheoCMND
            // 
            this.TKTheoCMND.Enabled = false;
            this.TKTheoCMND.Location = new System.Drawing.Point(768, 64);
            this.TKTheoCMND.Margin = new System.Windows.Forms.Padding(4);
            this.TKTheoCMND.Name = "TKTheoCMND";
            this.TKTheoCMND.Size = new System.Drawing.Size(184, 26);
            this.TKTheoCMND.TabIndex = 11;
            // 
            // cbTheoCMND
            // 
            this.cbTheoCMND.AutoSize = true;
            this.cbTheoCMND.Location = new System.Drawing.Point(616, 66);
            this.cbTheoCMND.Margin = new System.Windows.Forms.Padding(4);
            this.cbTheoCMND.Name = "cbTheoCMND";
            this.cbTheoCMND.Size = new System.Drawing.Size(124, 24);
            this.cbTheoCMND.TabIndex = 10;
            this.cbTheoCMND.Text = "Theo CMND";
            this.cbTheoCMND.UseVisualStyleBackColor = true;
            // 
            // TKTheoMa
            // 
            this.TKTheoMa.Enabled = false;
            this.TKTheoMa.Location = new System.Drawing.Point(768, 26);
            this.TKTheoMa.Margin = new System.Windows.Forms.Padding(4);
            this.TKTheoMa.Name = "TKTheoMa";
            this.TKTheoMa.Size = new System.Drawing.Size(184, 26);
            this.TKTheoMa.TabIndex = 9;
            // 
            // cbTheoMaKH
            // 
            this.cbTheoMaKH.AutoSize = true;
            this.cbTheoMaKH.Location = new System.Drawing.Point(616, 33);
            this.cbTheoMaKH.Margin = new System.Windows.Forms.Padding(4);
            this.cbTheoMaKH.Name = "cbTheoMaKH";
            this.cbTheoMaKH.Size = new System.Drawing.Size(125, 24);
            this.cbTheoMaKH.TabIndex = 8;
            this.cbTheoMaKH.Text = "Theo mã KH";
            this.cbTheoMaKH.UseVisualStyleBackColor = true;
            // 
            // TKDenNgay
            // 
            this.TKDenNgay.CustomFormat = "dd/MM/yyyy";
            this.TKDenNgay.Enabled = false;
            this.TKDenNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TKDenNgay.Location = new System.Drawing.Point(768, 100);
            this.TKDenNgay.Margin = new System.Windows.Forms.Padding(4);
            this.TKDenNgay.Name = "TKDenNgay";
            this.TKDenNgay.Size = new System.Drawing.Size(185, 26);
            this.TKDenNgay.TabIndex = 7;
            this.TKDenNgay.Value = new System.DateTime(2008, 12, 15, 0, 0, 0, 0);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(627, 102);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(86, 20);
            this.label13.TabIndex = 6;
            this.label13.Text = "đến ngày :";
            // 
            // TKTuNgay
            // 
            this.TKTuNgay.CustomFormat = "dd/MM/yyyy";
            this.TKTuNgay.Enabled = false;
            this.TKTuNgay.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TKTuNgay.Location = new System.Drawing.Point(272, 98);
            this.TKTuNgay.Margin = new System.Windows.Forms.Padding(4);
            this.TKTuNgay.Name = "TKTuNgay";
            this.TKTuNgay.Size = new System.Drawing.Size(243, 26);
            this.TKTuNgay.TabIndex = 5;
            this.TKTuNgay.Value = new System.DateTime(2008, 12, 15, 0, 0, 0, 0);
            // 
            // TKTheoTen
            // 
            this.TKTheoTen.Enabled = false;
            this.TKTheoTen.Location = new System.Drawing.Point(272, 65);
            this.TKTheoTen.Margin = new System.Windows.Forms.Padding(4);
            this.TKTheoTen.Name = "TKTheoTen";
            this.TKTheoTen.Size = new System.Drawing.Size(243, 26);
            this.TKTheoTen.TabIndex = 4;
            // 
            // TKTheoPhong
            // 
            this.TKTheoPhong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TKTheoPhong.Enabled = false;
            this.TKTheoPhong.FormattingEnabled = true;
            this.TKTheoPhong.Location = new System.Drawing.Point(272, 31);
            this.TKTheoPhong.Margin = new System.Windows.Forms.Padding(4);
            this.TKTheoPhong.Name = "TKTheoPhong";
            this.TKTheoPhong.Size = new System.Drawing.Size(243, 28);
            this.TKTheoPhong.TabIndex = 3;
            // 
            // cbThoiGian
            // 
            this.cbThoiGian.AutoSize = true;
            this.cbThoiGian.Location = new System.Drawing.Point(111, 100);
            this.cbThoiGian.Margin = new System.Windows.Forms.Padding(4);
            this.cbThoiGian.Name = "cbThoiGian";
            this.cbThoiGian.Size = new System.Drawing.Size(118, 24);
            this.cbThoiGian.TabIndex = 2;
            this.cbThoiGian.Text = "Thời gian ở ";
            this.cbThoiGian.UseVisualStyleBackColor = true;
            // 
            // cbTheoTen
            // 
            this.cbTheoTen.AutoSize = true;
            this.cbTheoTen.Location = new System.Drawing.Point(111, 66);
            this.cbTheoTen.Margin = new System.Windows.Forms.Padding(4);
            this.cbTheoTen.Name = "cbTheoTen";
            this.cbTheoTen.Size = new System.Drawing.Size(106, 24);
            this.cbTheoTen.TabIndex = 1;
            this.cbTheoTen.Text = "Theo Tên ";
            this.cbTheoTen.UseVisualStyleBackColor = true;
            // 
            // cbTheoPhong
            // 
            this.cbTheoPhong.AutoSize = true;
            this.cbTheoPhong.Location = new System.Drawing.Point(111, 33);
            this.cbTheoPhong.Margin = new System.Windows.Forms.Padding(4);
            this.cbTheoPhong.Name = "cbTheoPhong";
            this.cbTheoPhong.Size = new System.Drawing.Size(118, 24);
            this.cbTheoPhong.TabIndex = 0;
            this.cbTheoPhong.Text = "Theo phòng";
            this.cbTheoPhong.UseVisualStyleBackColor = true;
            // 
            // tpTraPhong
            // 
            this.tpTraPhong.Controls.Add(this.groupBox9);
            this.tpTraPhong.Controls.Add(this.groupBox8);
            this.tpTraPhong.Controls.Add(this.TPTinhTien);
            this.tpTraPhong.Location = new System.Drawing.Point(4, 29);
            this.tpTraPhong.Margin = new System.Windows.Forms.Padding(4);
            this.tpTraPhong.Name = "tpTraPhong";
            this.tpTraPhong.Size = new System.Drawing.Size(1339, 702);
            this.tpTraPhong.TabIndex = 3;
            this.tpTraPhong.Text = "Trả Phòng";
            this.tpTraPhong.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.dgtraphong);
            this.groupBox9.Location = new System.Drawing.Point(33, 31);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox9.Size = new System.Drawing.Size(1277, 279);
            this.groupBox9.TabIndex = 49;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Thông tin thuê phòng :";
            // 
            // dgtraphong
            // 
            this.dgtraphong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgtraphong.Location = new System.Drawing.Point(8, 26);
            this.dgtraphong.Margin = new System.Windows.Forms.Padding(4);
            this.dgtraphong.Name = "dgtraphong";
            this.dgtraphong.Size = new System.Drawing.Size(1261, 246);
            this.dgtraphong.TabIndex = 46;
            this.dgtraphong.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvThucDon_CellClick);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Controls.Add(this.txtmathuephong);
            this.groupBox8.Controls.Add(this.dtngaysinh);
            this.groupBox8.Controls.Add(this.txttongtien);
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.Controls.Add(this.txtdongiatp);
            this.groupBox8.Controls.Add(this.dttpngaybatdauthue);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.Controls.Add(this.dttpngayketthucthue);
            this.groupBox8.Controls.Add(this.label24);
            this.groupBox8.Controls.Add(this.txtTPPhong);
            this.groupBox8.Controls.Add(this.label21);
            this.groupBox8.Controls.Add(this.label20);
            this.groupBox8.Controls.Add(this.label19);
            this.groupBox8.Controls.Add(this.label18);
            this.groupBox8.Controls.Add(this.txtTPTenKH);
            this.groupBox8.Controls.Add(this.label16);
            this.groupBox8.Controls.Add(this.label15);
            this.groupBox8.Controls.Add(this.label14);
            this.groupBox8.Controls.Add(this.txtTPSoCMND);
            this.groupBox8.Controls.Add(this.txtTPSoDT);
            this.groupBox8.Controls.Add(this.txtTPDiaChi);
            this.groupBox8.Location = new System.Drawing.Point(108, 318);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox8.Size = new System.Drawing.Size(1107, 326);
            this.groupBox8.TabIndex = 48;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Thông tin khách hàng .";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(613, 28);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 20);
            this.label8.TabIndex = 49;
            this.label8.Text = "Phiếu thuê :";
            // 
            // txtmathuephong
            // 
            this.txtmathuephong.Location = new System.Drawing.Point(747, 28);
            this.txtmathuephong.Margin = new System.Windows.Forms.Padding(4);
            this.txtmathuephong.Name = "txtmathuephong";
            this.txtmathuephong.ReadOnly = true;
            this.txtmathuephong.Size = new System.Drawing.Size(251, 26);
            this.txtmathuephong.TabIndex = 50;
            // 
            // dtngaysinh
            // 
            this.dtngaysinh.CustomFormat = "dd/MM/yyyy";
            this.dtngaysinh.Enabled = false;
            this.dtngaysinh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtngaysinh.Location = new System.Drawing.Point(220, 138);
            this.dtngaysinh.Margin = new System.Windows.Forms.Padding(4);
            this.dtngaysinh.Name = "dtngaysinh";
            this.dtngaysinh.Size = new System.Drawing.Size(251, 26);
            this.dtngaysinh.TabIndex = 48;
            // 
            // txttongtien
            // 
            this.txttongtien.Location = new System.Drawing.Point(747, 235);
            this.txttongtien.Margin = new System.Windows.Forms.Padding(4);
            this.txttongtien.Name = "txttongtien";
            this.txttongtien.ReadOnly = true;
            this.txttongtien.Size = new System.Drawing.Size(251, 26);
            this.txttongtien.TabIndex = 47;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(613, 188);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 20);
            this.label7.TabIndex = 45;
            this.label7.Text = "Đơn giá :";
            // 
            // txtdongiatp
            // 
            this.txtdongiatp.Location = new System.Drawing.Point(747, 188);
            this.txtdongiatp.Margin = new System.Windows.Forms.Padding(4);
            this.txtdongiatp.Name = "txtdongiatp";
            this.txtdongiatp.ReadOnly = true;
            this.txtdongiatp.Size = new System.Drawing.Size(251, 26);
            this.txtdongiatp.TabIndex = 46;
            // 
            // dttpngaybatdauthue
            // 
            this.dttpngaybatdauthue.CustomFormat = "dd/MM/yyyy";
            this.dttpngaybatdauthue.Enabled = false;
            this.dttpngaybatdauthue.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dttpngaybatdauthue.Location = new System.Drawing.Point(747, 74);
            this.dttpngaybatdauthue.Margin = new System.Windows.Forms.Padding(4);
            this.dttpngaybatdauthue.Name = "dttpngaybatdauthue";
            this.dttpngaybatdauthue.Size = new System.Drawing.Size(251, 26);
            this.dttpngaybatdauthue.TabIndex = 43;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(613, 80);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(81, 20);
            this.label17.TabIndex = 28;
            this.label17.Text = "Từ Ngày :";
            // 
            // dttpngayketthucthue
            // 
            this.dttpngayketthucthue.CustomFormat = "dd/MM/yyyy";
            this.dttpngayketthucthue.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dttpngayketthucthue.Location = new System.Drawing.Point(748, 132);
            this.dttpngayketthucthue.Margin = new System.Windows.Forms.Padding(4);
            this.dttpngayketthucthue.Name = "dttpngayketthucthue";
            this.dttpngayketthucthue.Size = new System.Drawing.Size(251, 26);
            this.dttpngayketthucthue.TabIndex = 44;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(615, 239);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(118, 20);
            this.label24.TabIndex = 44;
            this.label24.Text = "Tổng Số Tiền :";
            // 
            // txtTPPhong
            // 
            this.txtTPPhong.Location = new System.Drawing.Point(220, 32);
            this.txtTPPhong.Margin = new System.Windows.Forms.Padding(4);
            this.txtTPPhong.Name = "txtTPPhong";
            this.txtTPPhong.ReadOnly = true;
            this.txtTPPhong.Size = new System.Drawing.Size(251, 26);
            this.txtTPPhong.TabIndex = 41;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(87, 81);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 20);
            this.label21.TabIndex = 24;
            this.label21.Text = "Họ và Tên :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(88, 140);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(95, 20);
            this.label20.TabIndex = 25;
            this.label20.Text = "Ngày Sinh :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(87, 188);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(95, 20);
            this.label19.TabIndex = 26;
            this.label19.Text = "Số CMND :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(88, 283);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 20);
            this.label18.TabIndex = 27;
            this.label18.Text = "Địa Chỉ :";
            // 
            // txtTPTenKH
            // 
            this.txtTPTenKH.Location = new System.Drawing.Point(220, 81);
            this.txtTPTenKH.Margin = new System.Windows.Forms.Padding(4);
            this.txtTPTenKH.Name = "txtTPTenKH";
            this.txtTPTenKH.ReadOnly = true;
            this.txtTPTenKH.Size = new System.Drawing.Size(251, 26);
            this.txtTPTenKH.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(613, 138);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(92, 20);
            this.label16.TabIndex = 29;
            this.label16.Text = "Đến Ngày :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(87, 235);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 20);
            this.label15.TabIndex = 30;
            this.label15.Text = "Số ĐT :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(87, 36);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 20);
            this.label14.TabIndex = 31;
            this.label14.Text = "Phòng :";
            // 
            // txtTPSoCMND
            // 
            this.txtTPSoCMND.Location = new System.Drawing.Point(220, 188);
            this.txtTPSoCMND.Margin = new System.Windows.Forms.Padding(4);
            this.txtTPSoCMND.Name = "txtTPSoCMND";
            this.txtTPSoCMND.ReadOnly = true;
            this.txtTPSoCMND.Size = new System.Drawing.Size(251, 26);
            this.txtTPSoCMND.TabIndex = 33;
            // 
            // txtTPSoDT
            // 
            this.txtTPSoDT.Location = new System.Drawing.Point(220, 235);
            this.txtTPSoDT.Margin = new System.Windows.Forms.Padding(4);
            this.txtTPSoDT.Name = "txtTPSoDT";
            this.txtTPSoDT.ReadOnly = true;
            this.txtTPSoDT.Size = new System.Drawing.Size(251, 26);
            this.txtTPSoDT.TabIndex = 35;
            // 
            // txtTPDiaChi
            // 
            this.txtTPDiaChi.Location = new System.Drawing.Point(220, 283);
            this.txtTPDiaChi.Margin = new System.Windows.Forms.Padding(4);
            this.txtTPDiaChi.Name = "txtTPDiaChi";
            this.txtTPDiaChi.ReadOnly = true;
            this.txtTPDiaChi.Size = new System.Drawing.Size(251, 26);
            this.txtTPDiaChi.TabIndex = 34;
            // 
            // TPTinhTien
            // 
            this.TPTinhTien.Location = new System.Drawing.Point(607, 651);
            this.TPTinhTien.Margin = new System.Windows.Forms.Padding(4);
            this.TPTinhTien.Name = "TPTinhTien";
            this.TPTinhTien.Size = new System.Drawing.Size(107, 39);
            this.TPTinhTien.TabIndex = 4;
            this.TPTinhTien.Text = "Tính Tiền";
            this.TPTinhTien.UseVisualStyleBackColor = true;
            this.TPTinhTien.Click += new System.EventHandler(this.TPTinhTien_Click);
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1379, 751);
            this.Controls.Add(this.Tabphong);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmmain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frm_load);
            this.Tabphong.ResumeLayout(false);
            this.tpDanhSanh.ResumeLayout(false);
            this.tpDanhSanh.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDanhSachphong)).EndInit();
            this.tpThuePhong.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgkhachhang)).EndInit();
            this.groupBDatPhong.ResumeLayout(false);
            this.groupBDatPhong.PerformLayout();
            this.tpTimKiem.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgTimKiem)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tpTraPhong.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgtraphong)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TabControl Tabphong;
        private System.Windows.Forms.TabPage tpDanhSanh;
        private System.Windows.Forms.Button btndangxuat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tpThuePhong;
        private System.Windows.Forms.Button bHuyBo;
        private System.Windows.Forms.Button btThuePhongOK;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBDatPhong;
        private System.Windows.Forms.CheckBox checkBDatPhongTruoc;
        private System.Windows.Forms.TextBox txtPhongtp;
        internal System.Windows.Forms.DateTimePicker dtTuNgaytp;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tpTimKiem;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DataGridView dgTimKiem;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox TKTheoDiaChi;
        private System.Windows.Forms.CheckBox cbTheoDiaChi;
        private System.Windows.Forms.TextBox TKTheoSoDT;
        private System.Windows.Forms.CheckBox cbTheoDT;
        private System.Windows.Forms.Button btTimKiem;
        private System.Windows.Forms.TextBox TKTheoCMND;
        private System.Windows.Forms.CheckBox cbTheoCMND;
        private System.Windows.Forms.TextBox TKTheoMa;
        private System.Windows.Forms.CheckBox cbTheoMaKH;
        private System.Windows.Forms.DateTimePicker TKDenNgay;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker TKTuNgay;
        private System.Windows.Forms.TextBox TKTheoTen;
        private System.Windows.Forms.ComboBox TKTheoPhong;
        private System.Windows.Forms.CheckBox cbThoiGian;
        private System.Windows.Forms.CheckBox cbTheoTen;
        private System.Windows.Forms.CheckBox cbTheoPhong;
        private System.Windows.Forms.TabPage tpTraPhong;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.DataGridView dgtraphong;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtTPPhong;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtTPTenKH;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTPSoCMND;
        private System.Windows.Forms.TextBox txtTPSoDT;
        private System.Windows.Forms.TextBox txtTPDiaChi;
        private System.Windows.Forms.Button TPTinhTien;
        private System.Windows.Forms.DataGridView dtgvDanhSachphong;
        private System.Windows.Forms.DataGridViewTextBoxColumn maPhong;
        private System.Windows.Forms.DataGridViewTextBoxColumn loaiPhong;
        private System.Windows.Forms.DataGridViewTextBoxColumn tinhTrang;
        private System.Windows.Forms.DataGridViewTextBoxColumn donGia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtmakhtp;
        private System.Windows.Forms.Label label4;
        internal System.Windows.Forms.DateTimePicker dtngaydattruoc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtphongdt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgkhachhang;
        private System.Windows.Forms.DataGridViewTextBoxColumn maKhachHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenKhachHang;
        private System.Windows.Forms.DataGridViewTextBoxColumn ngaySinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn gioiTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn chungMinhNhanDan;
        private System.Windows.Forms.DataGridViewTextBoxColumn soDienThoai;
        private System.Windows.Forms.DataGridViewTextBoxColumn diaChi;
        private System.Windows.Forms.DataGridViewTextBoxColumn quocTich;
        private System.Windows.Forms.DateTimePicker dttpngayketthucthue;
        private System.Windows.Forms.DateTimePicker dttpngaybatdauthue;
        private System.Windows.Forms.TextBox txttongtien;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtdongiatp;
        private System.Windows.Forms.DateTimePicker dtngaysinh;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtmathuephong;
    }
}